//
//  RootViewController.h
//  AppTest
//
//  Created by wesley chen on 15/6/26.
//
//

#import <UIKit/UIKit.h>

@interface RootViewController : UITableViewController

@end
