//
//  ViewController.m
//  HelloEditableTableView
//
//  Created by chenliang-xy on 15/8/3.
//  Copyright (c) 2015年 chenliang-xy. All rights reserved.
//

#import "RootViewController.h"
#import "MoveMeViewController.h"
#import "DeleteMeViewController.h"
#import "SelectMeViewController.h"
#import "InsertMeViewController.h"

@interface RootViewController () <UITableViewDataSource, UITableViewDelegate>
@property (nonatomic, strong) UITableView *tableView;
@property (nonatomic, strong) NSDictionary *listDict;
@end

@implementation RootViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
    self.title = @"Editable Table View";
    
    _tableView = [[UITableView alloc] initWithFrame:self.view.bounds style:UITableViewStylePlain];
    _tableView.delegate = self;
    _tableView.dataSource = self;
    [self.view addSubview:_tableView];
    
    _listDict = @{
                  @"Move Me" : [MoveMeViewController class],
                  @"Delete Me" : [DeleteMeViewController class],
                  @"Select Me" : [SelectMeViewController class],
                  @"Insert Me": [InsertMeViewController class],
                  };
}

#pragma mark - UITableViewDataSource

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *CellIdentifer = @"RootViewController_UITableViewCell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifer];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifer];
        cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    }
    
    cell.textLabel.text = _listDict.allKeys[indexPath.row];
    
    return cell;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return _listDict.count;
}

#pragma mark - UITableViewDelegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    Class cls = _listDict.allValues[indexPath.row];
    [self.navigationController pushViewController:[cls new] animated:YES];
}

@end
