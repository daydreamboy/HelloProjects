//
//  main.m
//  HelloEditableTableView
//
//  Created by chenliang-xy on 15/8/3.
//  Copyright (c) 2015年 chenliang-xy. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
