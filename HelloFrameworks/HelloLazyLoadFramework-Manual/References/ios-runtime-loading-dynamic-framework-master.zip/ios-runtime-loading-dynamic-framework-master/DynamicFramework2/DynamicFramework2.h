//
//  DynamicFramework2.h
//  DynamicFramework2
//
//  Created by Patrik Nyblad on 18/05/16.
//  Copyright © 2016 CarmineStudios. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for DynamicFramework2.
FOUNDATION_EXPORT double DynamicFramework2VersionNumber;

//! Project version string for DynamicFramework2.
FOUNDATION_EXPORT const unsigned char DynamicFramework2VersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <DynamicFramework2/PublicHeader.h>


