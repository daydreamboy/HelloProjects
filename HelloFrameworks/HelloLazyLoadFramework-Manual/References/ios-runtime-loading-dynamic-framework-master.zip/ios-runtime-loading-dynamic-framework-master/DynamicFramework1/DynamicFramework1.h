//
//  DynamicFramework1.h
//  DynamicFramework1
//
//  Created by Patrik Nyblad on 18/05/16.
//  Copyright © 2016 CarmineStudios. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for DynamicFramework1.
FOUNDATION_EXPORT double DynamicFramework1VersionNumber;

//! Project version string for DynamicFramework1.
FOUNDATION_EXPORT const unsigned char DynamicFramework1VersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <DynamicFramework1/PublicHeader.h>


