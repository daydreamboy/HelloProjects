//
//  CASHello.h
//  ios-dynamic-loading-framework
//
//  Created by Patrik Nyblad on 18/05/16.
//  Copyright © 2016 CarmineStudios. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CASHello : NSObject

+(void)hello;

@end
