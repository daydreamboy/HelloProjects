//
//  IconCell.swift
//  AdvancedCollectionView
//
//  Created by Ben Scheirman on 3/29/16.
//  Copyright © 2016 NSScreencast. All rights reserved.
//

import UIKit

class IconCell: UICollectionViewCell {
    
}
