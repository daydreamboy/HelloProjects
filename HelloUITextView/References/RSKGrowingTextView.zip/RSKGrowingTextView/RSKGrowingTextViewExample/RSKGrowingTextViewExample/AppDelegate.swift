//
//  AppDelegate.swift
//  RSKGrowingTextViewExample
//
//  Created by Ruslan Skorb on 12/14/15.
//  Copyright © 2015 Ruslan Skorb. All rights reserved.
//

import UIKit

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?

    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey : Any]? = nil) -> Bool {
        return true
    }
}
