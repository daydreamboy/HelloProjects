//
//  ViewController.swift
//  iOSUIPasteboard
//
//  Created by Anupam Chugh on 13/08/18.
//  Copyright © 2018 JournalDev. All rights reserved.
//

import UIKit
import MobileCoreServices

class ViewController: UIViewController {

    @IBOutlet weak var textFieldCopy: UITextField!
    @IBOutlet weak var textFieldPaste: UITextField!
    @IBOutlet weak var labelCopy: UILabel!
    @IBOutlet weak var labelPaste: UILabel!
    @IBOutlet weak var imageCopy: UIImageView!
    @IBOutlet weak var imagePaste: UIImageView!

    @IBAction func btnCopyStringAction(_ sender: Any) {
        UIPasteboard.general.string = textFieldCopy.text
    }
    
    
    @IBAction func btnPasteStringAction(_ sender: Any) {
        textFieldPaste.text = textFieldPaste.text! + UIPasteboard.general.string!
    }
    
    @IBAction func btnCopyUrlAction(_ sender: Any) {
        
        let oneHour = Date().addingTimeInterval(60 * 60)
        
        let pasteboard =  UIPasteboard.init(name: UIPasteboard.Name(rawValue: "sample_pasteboard"), create: true)
        pasteboard?.setItems([], options: [UIPasteboard.OptionsKey.localOnly : true, UIPasteboard.OptionsKey.expirationDate : oneHour])
        pasteboard?.setValue(URL(string: labelCopy!.text!) ?? "", forPasteboardType: kUTTypeURL as String)
    
    }
    
    @IBAction func btnPasteUrlAction(_ sender: Any) {
        
        let pasteboard = UIPasteboard.init(name: UIPasteboard.Name(rawValue: "sample_pasteboard"), create: true)
        labelPaste.text = pasteboard?.url?.absoluteString
    }
    
    @IBAction func btnCopyImageAction(_ sender: Any) {
        
        let image = imageCopy.image!
        if let data = image.pngData() {
            UIPasteboard.general.setData(data,forPasteboardType: kUTTypePNG as String)
        }
        
    }
    
    @IBAction func btnPasteImageAction(_ sender: Any) {
        
        
        let pasteboard = UIPasteboard.general
    
        let imageTypes = UIPasteboard.typeListImage as! [String]
        
        if pasteboard.contains(pasteboardTypes: imageTypes) {
            for imageType in imageTypes {
                if let data = pasteboard.data(forPasteboardType: imageType) {
                    if let pasteThisImage = UIImage(data: data) {
                        imagePaste.image = pasteThisImage
                        break
                    }
                }
            }
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
}

